package com.example.blogDB;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


@SpringBootApplication
public class BlogDbApplication {
	
	public Blogger createBlogger(String name, String password, String email) {	//create a new Blogger object
		return new Blogger(name, password, email);
	}
	
	public Post createPost(String title, String content, Blogger author) {	//create a new Post object
		return new Post(title, content, author);
	}
	
	@Autowired
	private BloggerRepository bloggerRep;
	
	@Autowired
	private PostRepository postRep;
	
	public static final Logger log = LoggerFactory.getLogger(BlogDbApplication.class);

	public static void main(String[] args) {

		SpringApplication.run(BlogDbApplication.class);

	}
	
	//test application
	@Bean
	public CommandLineRunner demo(BloggerRepository bloggerRep, PostRepository postRep) {
		return (args) -> {
			//save some dummy Bloggers
			bloggerRep.save(new Blogger("Alice Randomname", "Password1234", "alicer@gmail.com"));
			bloggerRep.save(new Blogger("Bob Othername", "rocky526", "BobbyO@gmail.com"));
			
			//fetch blogger by name
			System.out.println("Blogger found by name('Alice Randomname'):");
			List<Blogger> foo = bloggerRep.findByName("Alice Randomname");
			System.out.println(foo.toString());
			
			//save a post, with this blogger as author
			System.out.println("Posting a blog to this blogger");
			postRep.save(new Post("My First Blog!", "This is some text that I'm writing in the blog.\n This is some more text that is in the blog.", foo.get(0)));
			
			//find this post by author name
			List<Post> footwo = postRep.findByAuthor(foo.get(0));
			System.out.println(footwo.toString());
			
		};
	}
	
}
